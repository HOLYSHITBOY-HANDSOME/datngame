/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package board.game;

/**
 *
 * @author LAPTOP LE SON
 */
public class BoardGame {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
